# Estudo segundo trimestre
Marianna C. de Moraes - n°25
